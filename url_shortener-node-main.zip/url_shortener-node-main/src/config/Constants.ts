export const config = {
    API_URL: 'http://localhost:5000',
    MONGO_CONNECTION: 
    'mongodb+srv://lucasrmagalhaes:dio92@urlshortener-dio.go52y.mongodb.net/urlshortener?retryWrites=true&w=majority'
}